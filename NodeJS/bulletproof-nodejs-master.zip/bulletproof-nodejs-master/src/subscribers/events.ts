export default {
  user: {
    signUp: 'onUserSignUp',
    signIn: 'onUserSignIn',
  },
};
