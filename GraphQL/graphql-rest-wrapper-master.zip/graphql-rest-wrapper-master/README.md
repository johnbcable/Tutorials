# graphql-rest-wrapper

You can find more info about this repository [here](https://medium.com/@graphcool/how-to-wrap-a-rest-api-with-graphql-8bf3fb17547d).

> The REST API that's wrapped with GraphQL in this project can be found [here](https://github.com/nikolasburk/rest-demo).

## Usage

```sh
git clone git@github.com:nikolasburk/graphql-rest-wrapper.git
cd graphql-rest-wrapper
yarn start
```
