# social-graphql

An example app built alongside a blog post that shall soon be posted.

But since you found this early, heres a draft :)

https://medium.com/p/fc7fcabe8ebd/edit
