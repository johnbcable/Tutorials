export default `
  type Query {
    hi: String
  }
`;
