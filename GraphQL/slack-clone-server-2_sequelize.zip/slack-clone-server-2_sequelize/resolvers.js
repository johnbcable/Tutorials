export default {
  Query: {
    hi: (parent, args, context, info) => 'hi',
  },
};
